sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("namespace.com.Element_binding_path_router.controller.View1", {
		onInit: function () {

		}
	});
});