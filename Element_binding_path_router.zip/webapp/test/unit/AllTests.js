sap.ui.define([
	"namespace/com/Element_binding_path_router/test/unit/controller/View1.controller"
], function () {
	"use strict";
});