/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"namespace/com/Element_binding_path_router/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});