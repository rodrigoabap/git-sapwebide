sap.ui.define([
	"Routing/Routing/test/unit/controller/app.controller"
], function () {
	"use strict";
});