sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",        // add a classe filter
	"sap/ui/model/FilterOperator"// add a classe operador do filtro
], function (Controller, Filter, FilterOperator) { // obs aqui passamos dois parametros e demos o mesmo nome que as classes, mas poderia ser outro nome
	"use strict";

	return Controller.extend("ListaProdutos.ListaProdutos.controller.View1", {
		onInit: function () {

		},
		
		onFilter: function(evt){
			var query = evt.getSource().getValue();//variavel query vai receber o get.value do nosso sourch field (vai receber o valor digitado pelo
			//usuário no search field da pagina web)
			
			var oFilter = new Filter({//aqui a variavel OFilter faz referencia a nosso parametro Filter
				filters:[
						new Filter("BusinessPartnerID", FilterOperator.Contains, query), // filtro BusinessPartnerID digitado pelo usuário para fazer a busca
						new Filter("CompanyName", FilterOperator.Contains, query)// filtro CompanyName digitado pelo usuário para fazer a busca
					],
				and: false
			});
			
			
			//Atualização do nosso list
			var list  = this.getView().byId("list0");// id do list que foi criado na view
			var binding = list.getBinding("items");// Aqui vai armazenar as informações do items (ProducSet) que esta dentro do list
			
			binding.filter(oFilter);// encapsulando dentro do binding.filter a variavel Ofilter
		},
		
		handleGroup: function(evt){
			
			var sorters = [];
			var item = evt.getParameter("selectedItem");// Quando o user selecionar, a variavel item armazena o que ele selecionou.
			var Key = (item) ? item.getKey() : null; // armazena a verificação se a variavel item foi selecionado se não fica nullo
			
			if(Key === "Category"){
				sorters.push(new sap.ui.model.Sorter(Key,false,true));
			} else if(Key === "Price"){// o key é o nome do key do list da view que definimos como Price.
				var grouper = this.getView().getController().Price; //Estou acessando a função price do controller.js e armazenando na variavel grouper
				sorters.push(new sap.ui.model.Sorter(Key,true,grouper));//ordena o key(price) true descendente e grouper esta a função price
			}
			
			var list = this.getView().byId("list1");// Esse list1 é o id do list definido na view
			var oBinding = list.getBinding("items");//Lista o item do list1 da view
			oBinding.sort(sorters);//aplica a Ordenação
		},
		Price: function(oContext){ // Função criada(Price) E PASSEI oContext que simbolizara o contexto de cada linha(valores) das propriedades
			var price = oContext.getProperty("Price");// getProperty acessa a price, e armazeno o valor da propriedade price na variavel price
			var currency = oContext.getProperty("CurrencyCode");// getProperty acessa a CurrencyCod e armazeno o valor da propriedade CurrencyCode na 
			// variavel currency
			var key = null;
			var text = null;
			
			if(price <= 1000){
				key ="<";// KEY recebe <
				text="<= 1000 " + currency;// VARIAVEL TEXT RECEBE A CONCATENAÇÃO DE ( <= 1000 + moeda(USD) )
			}else if(price > 1000 && price <= 10000){
				key =" ";// KEY recebe vazio
				text="<= 10000 " + currency;// VARIAVEL TEXT RECEBE A CONCATENAÇÃO DE ( <= 10000 + moeda(USD) )					
		    }else if(price > 10000){
				key =">";// KEY recebe >
				text="> 10000 " + currency;	// VARIAVEL TEXT RECEBE A CONCATENAÇÃO DE ( > 10000 + moeda(USD) )		
			}	
			return {
				key: key,
				text: text
			};
		}
		
	});
});