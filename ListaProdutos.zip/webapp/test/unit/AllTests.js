sap.ui.define([
	"ListaProdutos/ListaProdutos/test/unit/controller/View1.controller"
], function () {
	"use strict";
});