sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ZAP_VIM_Report.controller.V_Root", {

	});
});