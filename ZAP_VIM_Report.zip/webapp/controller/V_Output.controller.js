sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("ZAP_VIM_Report.controller.V_Output", {

		onInit: function() {
			// Get the Router Info
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			// Validate/Match the Router Output sent from Input Controller
			oRouter.getRoute("Route_Output").attachMatched(this._onRouteFound, this);
		},
		
		// Custom Method to bind the elements using the Event Arguments
		_onRouteFound: function(oEvt) {
			// debugger;
			// Identica os parametros com os valores da tela(input) anterior
			var oArgument = oEvt.getParameter("arguments");
			// pega o valor do parametro ip_prod
			var lv_prod = oArgument.ip_prod;
			
			// var oView = this.getView();caso fosse odata
			
			//var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGW_VIM_APP2_SRV/");// caso fosse odata
			
			//EU DEFINI, p que encontre o model/entidade
			var oModel = this.getView().getModel();
			this.getView().setModel(oModel);
			
			// Aqui fiz o fitro, que no caso ira filtrar pelo id do produto               
			var filters = new sap.ui.model.Filter({
				and: true,
				filters: [new sap.ui.model.Filter("ProductID", sap.ui.model.FilterOperator.EQ, lv_prod)]
			});
			// Aqui vai mostrar o registro que encontrar no list do item da nossa tela
			var binding = this.byId("list").getBinding("items");
			binding.filter(filters);// mostra o registro que foi encontrado pelo filtro
		},

		// Go Back to Input View
		NavToInputView: function(oEvt) {
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Route_Input", {});
		},

		// Go Forward to Detail View
		NavToDetailView: function(oEvt) {
			// alert("hello you clicked the right button");
			// debugger;
			
			var selprod = oEvt.getSource().getBindingContext().getProperty("ProductID");
			//obs que estou pegando o valor do suplierid.
			var selsupp = oEvt.getSource().getBindingContext().getProperty("SupplierID");

			var oRouter1 = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter1.navTo("Route_Detail", {
				p_prod: selprod,
				//lembra que peguei o valor do supplierid, vou passar ele nessa variavel p_supp para podermos chamarmos ele na tela
				// Detail, ai sim eu conseguirei mostrar os dados da entidade supplier que é entidade filha da products
			 	p_supp: selsupp 
			//	p_gjahr: selGjahr
			});

		}
	});
});