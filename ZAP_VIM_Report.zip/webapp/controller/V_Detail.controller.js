sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/routing/History"], function(Controller,History) {
	"use strict";

	return Controller.extend("ZAP_VIM_Report.controller.V_Detail", {
		onInit: function() {
			// Get the Router Info
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// Validate/Match the Router Details sent from Input Controller
			oRouter.getRoute("Route_Detail").attachMatched(this._onRouteFound, this);
		},
		
		_onRouteFound: function(oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			
			// peguei o valor do parametro, mas nem estou usando esse
			var lv_prod = oArgument.p_prod;
			
			// lembra do parametro do supplierid que pegamos na tela anterior(v_output), olha ele ai
			var lv_supp = oArgument.p_supp;
			
			//var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGW_VIM_APP2_SRV/");
			var oModel = this.getView().getModel(); //EU DEFINI
			this.getView().setModel(oModel);

			var filters = new sap.ui.model.Filter({
				and: true,
				filters: [
					new sap.ui.model.Filter("SupplierID", sap.ui.model.FilterOperator.EQ, lv_supp)
				]
			});
			var binding = this.byId("list").getBinding("items");
			binding.filter(filters);
		},

		// Go Back to Output View
		GoToOutput: function(evt) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Route_Input", true);
			}			

		}

	});

});