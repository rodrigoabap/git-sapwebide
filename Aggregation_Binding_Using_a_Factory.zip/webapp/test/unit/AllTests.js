sap.ui.define([
	"nspace/Aggregation_Binding_Using_a_Factory/test/unit/controller/View1.controller"
], function () {
	"use strict";
});