/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"nspace/Aggregation_Binding_Using_a_Factory/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});