sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("nspace.Aggregation_Binding_Using_a_Factory.controller.View1", {
		onInit: function () {

		}
	});
});