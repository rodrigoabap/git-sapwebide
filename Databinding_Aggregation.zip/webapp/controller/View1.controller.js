sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel"
], function (Controller) {
	"use strict";

	return Controller.extend("projetc_dt.Databinding_Aggregation.controller.View1", {
		onInit: function () {
			var oModel = new sap.ui.model.json.JSONModel(); /** Crio a instancia do jason**/
			
			oModel.loadData("model/Products.json"); /**Vinculamos nosso arquivo jason atraves do medoto loadData armazenando no nosso 
			//objeto oModel que criamos (VAR)**/
			
			var oView = this; /**Crio o objeto oView do tipo this**/
			
			oView.getView().setModel(oModel,"Produtos");//**Associa o model(oModel) a nosso objeto View
		 
		}
	});
});