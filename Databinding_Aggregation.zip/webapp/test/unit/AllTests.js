sap.ui.define([
	"projetc_dt/Databinding_Aggregation/test/unit/controller/View1.controller"
], function () {
	"use strict";
});