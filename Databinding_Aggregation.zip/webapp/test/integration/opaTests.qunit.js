/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"projetc_dt/Databinding_Aggregation/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});