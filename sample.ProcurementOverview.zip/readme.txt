SAP Fiori Reference Application based on Fiori Elements, demonstrating how to implement an overview page
