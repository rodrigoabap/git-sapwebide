sap.ui.define([
	"ovly/hanadeveloper/smartchart/test/unit/controller/View1.controller"
], function () {
	"use strict";
});