sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("br.com.sccdemo.Proj_SCC_Demo.controller.View1", {
		onInit: function () {

		}
	});
});