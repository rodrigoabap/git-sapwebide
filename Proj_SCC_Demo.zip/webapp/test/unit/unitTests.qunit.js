/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"br/com/sccdemo/Proj_SCC_Demo/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});