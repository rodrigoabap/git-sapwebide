sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("DataBinding_Element.DataBinding_Element.controller.View1", {
		
		onInit: function () {
			
			var oModel = new sap.ui.model.json.JSONModel();/** Crio a instancia do jason**/
			
			oModel.loadData("model/Products_Suppliers.json");  /**Vinculamos nosso arquivo jason atraves do medoto loadData armazenando no nosso 
			objeto oModel que criamos (VAR)**/  
			
			var oView = this; /**Crio o objeto oView do tipo this**/
			
			oView.getView().setModel(oModel,"bElement");	/**Associa o model(oModel) a nosso objeto View
			                          Obs que define um nome/alies(Element) ao model **/
			oView.getView().bindElement(
				{
				   path:"/Products/2",/**Aqui estou informando o caminho do bindElement, significa que ira pegar na minha
				   entidade Produtos o indice/ID 2, PEGANDO A INFORMAÇÃO DO PRODUTO 2**/
				   model: "bElement" /** caso vc n deu um nome p o model,
				   n precisa passar a intrução ,model:bElement **/
			    }
			    );
			    
		},
		onBeforeRendering:function(){ /**Antes que rendenrece a função OnInit, o onBefore ira acessar o elemento
		supplier dentro da entidade produtos**/
			
		    this.byId("form0").bindElement("bElement>Supplier"); /**Aqui estamos acessando nosso formulario form0 que criamos na view
		    e falando qual elemento (Supplier) que iremos acessar**/
			
		}
		
	});
});