sap.ui.define([
	"OPERATIONS/ADD_AND_DELETE_OPERATIONS_LIST_CONTROL/test/unit/controller/View1.controller"
], function () {
	"use strict";
});