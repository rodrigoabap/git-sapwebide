sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",        // add a classe filter
	"sap/ui/model/FilterOperator",// add a classe operador do filtro
	"sap/ui/model/odata/ODataModel"
], function (Controller, Filter, FilterOperator, ODataModel) { // obs aqui passamos dois parametros e demos o mesmo nome que as classes, mas poderia ser outro nome
	"use strict";

	return Controller.extend("OPERATIONS.ADD_AND_DELETE_OPERATIONS_LIST_CONTROL.controller.View1", {
		onInit: function () {
			
		// create and set ODATA Model
		//	this.Produtos = new ODataModel("/gwsample_basic", true);
		//	this.getView().setModel(this.Produtos);
		
		},
		
		OnAddClick1: function () {

			var oModel = this.getView().getModel("Produtos");
			var oData = oModel.getData();
			oData.Products.unshift({
				"Title": "Gionee",
				"Price": "6000"
			});
			oModel.setData(oData);

		},
		OnAddClick: function () {

			var oModel = this.getView().getModel('Produtos');
			var oData = oModel.getData();
			oData.BusinessPartnerSet.unshift({
				"BusinessPartnerID": "Gionee",
				"CompanyName": "6000"
			});
			oModel.setData(oData);

		},		
		onSearch: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("CompanyName", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = this.byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},		
		onDelete3: function (oEvent) {
			this.getView().byId("list");
			// calculating the index of the selected list item
			var oItem = oEvent.getParameter('listItem');
		    var sPath = oItem.getBindingContext('Produtos').getPath();
			var iLength = sPath.length;
			var iIndex = sPath.slice(iLength - 1);
			// Removing the selected list item from the model based on the index
			// calculated
			var oModel = this.getView().getModel("Produtos");
			var oData = oModel.oData;
			var removed = oData.Produtos.splice(iIndex, 1);
			oModel.setData(oData);
		},
		onDelete: function(oEvent) {
			var oList = oEvent.getSource(),
				oItem = oEvent.getParameter("listItem"),
				sPath = oItem.getBindingContext('Produtos').getPath();

			// after deletion put the focus back to the list
			oList.attachEventOnce("updateFinished", oList.focus, oList);

			// send a delete request to the odata service
			this.Produtos.remove(sPath);
		},		
        onDelete2: function(oEvent) {
          var oItem = oEvent.getSource().getParent();
          var oTable = oItem.getParent();
          var oIndex = oTable.indexOfItem(oItem);
          if (oIndex !== -1) {
            var m = oTable.getModel();
            var data = m.getProperty("/");
            var removed = data(oIndex, 1);
            m.setProperty("/", data);
           // alert(JSON.stringify(removed[0]) + 'is removed');
          } else {
           // alert.('Please select a row');
          }
        }		
	});
});