sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"DemoMock/DemoMock/util/Formatter" // Chamamos nosso arquivo formatter, passando caminho onde ele se encontra
], function(Controller, Formatter) { // Criamos a variavel Formatter 
	"use strict";

	return Controller.extend("DemoMock.DemoMock.controller.View1", {
		Formatter: Formatter // Aqui no return, será retornado na variavel formatter o arquivo externo formatter
	});
});