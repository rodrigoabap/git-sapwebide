sap.ui.define(function(){
	"use strict";
	
	var Formatter = {
		//Inserir as nossas funções
		
		statusText: function(vWeight, vMeasure){ //Criei uma função chamada statusText, que recebe duas variaveis (vWeight, vMeasure)
			
			var sResult = "";// criei variavel sResult
			// Vamos fazer a checagem dessas variaveis
			if(vMeasure === "G"){
				vWeight = vWeight / 1000;
			}
			
			if(vWeight < 0.5){
				sResult = "Peso menor que 0.5 KG";
			}else if(vWeight < 10){
				sResult = "Peso menor que 10 KG";
			}else{
				sResult = "Peso maior que 10 KG";
			}	
			
			return sResult;	
			
		},
        
        //criando outra função (statusState)
		statusState: function(vWeight, vMeasure){ //Criei uma função chamada statusText, que recebe duas variaveis (vWeight, vMeasure)
			
			var sResult = "None";// criei variavel sResult
			// Vamos fazer a checagem dessas variaveis
			if(vMeasure === "G"){
				vWeight = vWeight / 1000;
			}
			
			if(vWeight < 0.5){
				sResult = "Error";
			}else if(vWeight < 10){
				sResult = "Warning";
			}else{
				sResult = "Success";
			}	
			
			return sResult;	
			
		}
		
	};
	
	return Formatter;
	
	
},true);