sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox" //objeto de controle para apresentar as menssages do i18n quando o user clicar nos botões
], function (Controller,MessageBox) { // atribui o messagebox na function
	"use strict";

	return Controller.extend("Localization_Proj.Localization_Proj.controller.Localization", {
		onInit: function () {
			var oView = this.getView();// REFERENCIA/PEGA A NOSSA VIEW
			var oPath = "/BusinessPartnerSet('0100000020')";// Caminho do odata /sap/opu/odata/IWBEP/gwsample_basic/BusinessPartnerSet('0100000020') e passamos a entidade
			                                                // /BusinessPartnerSet e o ID 0100000020 
			
			oView.bindElement({//Dentro da nossa view estou fazendo nosso bindElement, 
				path: oPath,// passando nossa variavel do caminho de nevegação
				model: "MDL_Fornecedor",// O nosso model que criamos com esse nome, caso n tivessemos criado um nome p o model, n precisaria passar essa linha de comando
				events: { // E os eventos na tela para ele fazer a proteção na tela enquando estiver fazendo chamado no serviço
					dataRequested: function(){
						oView.setBusy(true);
					},
					dataReceived: function(){
						oView.setBusy(false);
					}
				}
			});
			
			//Fazer teste de troca de Idioma
			var oModel = new sap.ui.model.resource.ResourceModel({//Acesso o resource do model
				bundleName: "Localization_Proj.Localization_Proj.i18n.i18n_es" //acesso a pasta i18n e o arquivo i18n_es
			});
			
			oView.setModel(oModel, "i18n");// set o model e a pasta

		},
		onUpdate:function(){
			var oBundle = this.getView().getModel("i18n").getResourceBundle();// criei a variavel, getando a view/model i18n com o metodo getResourceBundle.
			MessageBox.success(oBundle.getText("MsgUpdate"));// Aqui é aonde vai pegar a menssagem que criamos dentro do campo MsgUpdate do arquivo i18n
		},
		
		onDelete:function(){
			var oBundle = this.getView().getModel("i18n").getResourceBundle();// criei a variavel, getando a view/model i18n com o metodo getResourceBundle.
			var oSupplier = "0100000020";
			MessageBox.warning(oBundle.getText("MsgDelete",[oSupplier]));// Aqui é aonde vai pegar a menssagem que criamos dentro do campo MsgDelete do arquivo i18n
			// o oSupplier vai entra como parametro de concatenação, por que la no i18n definimos na msg do MsgDelete a msg + {0} + msg, então o oSupplier entra no {0}
		}	
	});
});