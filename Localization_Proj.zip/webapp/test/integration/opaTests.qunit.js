/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Localization_Proj/Localization_Proj/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});