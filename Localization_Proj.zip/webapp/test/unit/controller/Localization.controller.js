/*global QUnit*/

sap.ui.define([
	"Localization_Proj/Localization_Proj/controller/Localization.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Localization Controller");

	QUnit.test("I should test the Localization controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});