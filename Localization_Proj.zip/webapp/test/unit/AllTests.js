sap.ui.define([
	"Localization_Proj/Localization_Proj/test/unit/controller/Localization.controller"
], function () {
	"use strict";
});