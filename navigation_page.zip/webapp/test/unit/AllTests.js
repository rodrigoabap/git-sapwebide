sap.ui.define([
	"namespace/navigation_page/test/unit/controller/View1.controller"
], function () {
	"use strict";
});