sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter" //n esqueça de colocar essa linha p o filtro
], function (Controller, Filter) {// define o constructor Filter
	"use strict";

	return Controller.extend("namespace.navigation_page.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf namespace.navigation_page.view.View2
		 */
		onInit: function () {
			var oTable2 = this.getView().byId("table2");//estamos fornecendo o id da tabela que foi definido view1 para obter a visão da tabela e mantida na variável “oTable”. 
			var oModel = new sap.ui.model.json.JSONModel();// instancia o Model animals
			oModel.loadData("model/animals.json");//estamos obtendo todos os dados e carregando esses dados na variável “oModel”. 
			oTable2.setModel(oModel);//vinculando os dados (que estão presentes na variável oModel) à tabela(oTable).
		},
		//Filtro de pesquisa
		onSearch: function(oEvt){
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("name", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
				
			}
			//Mostra na saida apenas o que acho na pesquisa.
			var list = this.getView().byId("table2");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
			
		},
		onBack: function(){//function p voltar a page view1
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");//Volta p view1
		}

	});

});