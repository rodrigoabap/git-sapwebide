sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("namespace.navigation_page.controller.View1", {
		
		onInit: function () {
			debugger;
			var oTable = this.getView().byId("table0");//estamos fornecendo o id da tabela que foi definido view1 para obter a visão da tabela e mantida na variável “oTable”. 
			var oModel = new sap.ui.model.json.JSONModel();// instancia o Model animals
			oModel.loadData("model/animals.json");//estamos obtendo todos os dados e carregando esses dados na variável “oModel”. 
			oTable.setModel(oModel);//vinculando os dados (que estão presentes na variável oModel) à tabela(oTable).
		},
		
		onPress: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);//vARIAVEL GET ROUTER
			oRouter.navTo("View2");//ROUTER NAVEGA PARA VIEW2
		}
	});
});