sap.ui.define([
	"br/com/infoprodutos/Produtos/test/unit/controller/App.controller"
], function () {
	"use strict";
});