sap.ui.define([
	"sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	
	return Controller.extend("namespace.creat_delete_update_read_odata.controller.crud_demo", {
		onInit: function () {
			
			//this = this;
			// Create Model Instance of the oData service
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZCRUD_DEMO_SRV/");
			sap.ui.getCore().setModel(oModel, "myModel");
		},
		oDataCall: function (oEvent) {
			// call oData service's function based on which button is clicked.
			debugger;
			var myModel = sap.ui.getCore().getModel("myModel");
			myModel.setHeaders({
				"X-Requested-With": "X"
			});
			// CREATE******************
			if ('Create' == oEvent.oSource.mProperties.text) {
				var obj = {};
				obj.id = this.getView().byId("uniqueid").getValue();
				obj.name = this.getView().byId("nameid").getValue();
				obj.email = this.getView().byId("emailid").getValue();
				obj.mobile = this.getView().byId("mobid").getValue();
				myModel.create('/userdataSet', obj, {
					success: function (oData, oResponse) {
						debugger;
						alert('Record Created Successfully...');
					},
					error: function (err, oResponse) {
						debugger;
						alert('Error while creating record - '
							.concat(err.response.statusText));
					}
				});
			}
			// READ******************
			else if ('Read' == oEvent.oSource.mProperties.text) {
				var readurl = "/userdataSet?$filter=(id eq '')";
				myModel.read(readurl, {
					success: function (oData, oResponse) {
						debugger;
						var userdata = new sap.ui.model.json.JSONModel({
							"Result": oData.results
						});
						var tab = this.getView().byId("userdatatable");
						tab.setModel(userdata);
						var i = 0;
						tab.bindAggregation("items", {
							path: "/Result",
							template: new sap.m.ColumnListItem({
								cells: [new sap.ui.commons.TextView({
									text: "{id}",
									design: "H5",
									semanticColor: "Default"
								}), new sap.ui.commons.TextView({
									text: "{name}",
									design: "H5",
									semanticColor: "Positive"
								}), new sap.ui.commons.TextView({
									text: "{email}",
									design: "H5",
									semanticColor: "Positive"
								}), new sap.ui.commons.TextView({
									text: "{mobile}",
									design: "H5",
									semanticColor: "Positive"
								}), ]
							})
						});
					},
					error: function (err) {
						debugger;
					}
				});
			}
			// UPDATE******************
			if ('Update' == oEvent.oSource.mProperties.text) {
				var obj = {};
				obj.id = this.getView().byId("uniqueid").getValue();
				obj.email = this.getView().byId("emailid").getValue();
				var updateurl = "/userdataSet(id='" + this.getView().byId("uniqueid").getValue() + "')";

				myModel.update(updateurl, obj, {
					success: function (oData, oResponse) {
						debugger;
						alert('Record Updated Successfully...');
					},
					error: function (err, oResponse) {
						debugger;
						alert('Error while updating record - '
							.concat(err.response.statusText));
					}
				});
			}
			// DELETE******************
			if ('Delete' == oEvent.oSource.mProperties.text) {
				var delurl = "/userdataSet(id='" + this.getView().byId("uniqueid").getValue() + "')";
				myModel.remove(delurl, {
					success: function (oData, oResponse) {
						debugger;
						alert('Record Removed Successfully...');
					},
					error: function (err, oResponse) {
						debugger;
						alert('Error while removing record - '
							.concat(err.response.statusText));
					}
				});
			}
		}
	});
});