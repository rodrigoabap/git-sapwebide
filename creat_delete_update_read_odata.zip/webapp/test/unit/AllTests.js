sap.ui.define([
	"namespace/creat_delete_update_read_odata/test/unit/controller/crud_demo.controller"
], function () {
	"use strict";
});