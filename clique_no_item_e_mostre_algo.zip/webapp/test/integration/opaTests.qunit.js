/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"demo/sap/clique_no_item_e_mostre_algo/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});