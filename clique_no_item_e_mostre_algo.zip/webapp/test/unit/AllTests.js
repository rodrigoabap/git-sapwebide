sap.ui.define([
	"demo/sap/clique_no_item_e_mostre_algo/test/unit/controller/View1.controller"
], function () {
	"use strict";
});