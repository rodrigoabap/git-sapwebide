sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";
 
	return Controller.extend("demo.sap.clique_no_item_e_mostre_algo.controller.View1", {
    onInit: function () {
// Primeiro, criando dados de funcionários no formato JSON. 'emp' é o nó raiz.	
			var oEmpData = 
			{
	"emp": [{
			"empid": "111111",
			"empname": "John Walter",
			"exp": "120 months",
			"age": "34",
			"city": "Colombo",
			"country":"Sri Lanka",
			"cadre": "Band 5",
			"designation": "Delivery Manager",
			"projects": [{
					"projectid": "PGIMPL",
					"projectname": "P & G SAP Implementation"
				},
				{
					"projectid": "ARMSUPPORT",
					"projectname": "Aramco Support"
				}
			]
		},
		{
			"empid": "222222",
			"empname": "Rashid Khan",
			"exp": "40 months",
			"age": "34",
			"city": "Mumbai",
			"country":"India",
			"cadre": "Band 1",
			"designation": "Software Engineer",
			"projects": [{
					"projectid": "TATAIMPL",
					"projectname": "Tata SAP Implementation"
				},
				{
					"projectid": "AIRIMPL",
					"projectname": "AIRBUS Implementation"
				}
			]
		},
		{
			"empid": "333333",
			"empname": "Supriya Singh",
			"exp": "60 months",
			"age": "34",
			"city": "Tokyo",
			"country":"Japan",
			"cadre": "Band 3",
			"designation": "Sr. Software Engineer",
			"projects": [{
					"projectid": "PGIMPL",
					"projectname": "P & G SAP Implementation"
				},
				{
					"projectid": "ARMSUPPORT",
					"projectname": "Aramco Support"
				}
			]
		}
	]
};

// estamos criando uma instância do modelo JSON usando dados de funcionários. var oModel = novo JSONModel (oEmpData);
var oModel = new JSONModel(oEmpData);
// estamos definindo o Modelo para a Visualização para que seus dados estejam disponíveis 
//para os controles da visualização para ligação. this.getView (). setModel (oModel);
this.getView().setModel(oModel);
		},
        onObjectItemPress:function(oEvent)
		{
			var oItem = oEvent.getSource();//identifica qual controle disparou o evento.
			var oCtx = oItem.getBindingContext();//obtem o contexto de ligação
			var path = oCtx.getPath();//caminho da ligação da nossa lista de itens.
			this.getView().byId("objectid").bindElement(path);//caminho para fazer uma ligação de elemento
			//em qualquer outro controle (neste caso, ObjectHeader) e exibir os dados disponíveis nesse caminho.
			// alert(oEvent.getSource());
		}		
	});
});
