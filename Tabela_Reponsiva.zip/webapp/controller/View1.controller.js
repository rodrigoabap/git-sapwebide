sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Tabela_Reponsiva.Tabela_Reponsiva.controller.View1", {
		onInit: function () {
			var oModel = this.getView().getModel("device");// gueta o model device, conforme sabemos devido o debug
			var oVisible = oModel.getData().system.phone;//retorna se a app foi executada pelo phone, se sim é true ou se não é false.
			
			var oButton = this.getView().byId("button0");//gueta o botão Id=button0
			oButton.setVisible(oVisible);// e aqui eu o botão vai ser visible se a variavel oVisible for true.
		}
	});
});