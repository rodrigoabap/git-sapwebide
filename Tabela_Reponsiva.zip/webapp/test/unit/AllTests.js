sap.ui.define([
	"Tabela_Reponsiva/Tabela_Reponsiva/test/unit/controller/View1.controller"
], function () {
	"use strict";
});