/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Tabela_Reponsiva/Tabela_Reponsiva/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});