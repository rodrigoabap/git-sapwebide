sap.ui.define([
	"namespace/ADD_PACK_E_EXCLUIR_LINHA/test/unit/controller/V_Detail.controller"
], function () {
	"use strict";
});