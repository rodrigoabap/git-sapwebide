sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Proj_fragments.Proj_fragments.controller.ListaProdutos", {
		onInit: function () {

		},
		
		onDetalhes: function(evt){
			
			if(!this._oDialog){ //Se o objeto _oDialog não estiver criado, ai ele entra dentro if e cria, exemplo a 1* vez que o user clicar no botão
			   // ele entra na linha abaixo e cria o objeto e armazena na memoria, então após a criação quando o user clicar no botão ele n entra mais
			   //if
				this._oDialog = sap.ui.xmlfragment("Proj_fragments.Proj_fragments.frags.Fornecedor", this);
				this.getView().addDependent(this._oDialog); // o objeto é criado com uma dependencia para nossa view.
			}
			
			var oObj = evt.getSource().getBindingContext(); //Aqui estamos pegando o contexto do que clicamos
			var oPath = oObj.getPath(); // Aqui estamos passando o caminho do que clicamos
			
			var oView = this.getView(); //Aqui mostra minha view corrente( aview que estamos operando)
			var oForm = sap.ui.getCore().byId("form0");// aqui estamos acessando o simpleform do fragment Fornecedor.fragment.xml
			
			oForm.bindElement({// Dentro do simpleform temos o bindElement, onde temos uma coleção de elemento, mas iremos acessar somente um (supplier)
				path: oPath + "/Supplier", // Aqui estamos concatenando o caminho("Products(N* DO PRODUTO)/Supplier) - CASO N ENTENDEU, DEBUGUE NESSA PARTE
				events:{
					dataRequested: function(){// aqui estamos pausando a view até retorna os dados no simpleform, apos retorna os dados, ele coloca p false
					 //como se fosse um temporizador de pausa.
						oView.setBusy(true);
					},
					dataReceived:  function(){
						oView.setBusy(false);
					}
				}
			});
			
			this._oDialog.open(); // abre o objeto _oDialog que esta enca´psulado dentro no nosso fragmente
			
		},
		
		onClose: function(){
			this._oDialog.close();
		}
		
	});
});