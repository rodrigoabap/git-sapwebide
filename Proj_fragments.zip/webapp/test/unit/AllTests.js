sap.ui.define([
	"Proj_fragments/Proj_fragments/test/unit/controller/ListaProdutos.controller"
], function () {
	"use strict";
});