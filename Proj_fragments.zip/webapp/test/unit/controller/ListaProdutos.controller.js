/*global QUnit*/

sap.ui.define([
	"Proj_fragments/Proj_fragments/controller/ListaProdutos.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ListaProdutos Controller");

	QUnit.test("I should test the ListaProdutos controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});