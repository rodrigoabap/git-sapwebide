sap.ui.define([
	"ovly/hanadeveloper/smarttable/test/unit/controller/View1.controller"
], function () {
	"use strict";
});