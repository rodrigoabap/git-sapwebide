sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ovly.hanadeveloper.smarttable.controller.View1", {
		onInit: function () {

		}
	});
});