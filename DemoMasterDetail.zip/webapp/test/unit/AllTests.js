sap.ui.define([
	"org/unity/DemoMasterDetail/test/unit/controller/View1.controller"
], function () {
	"use strict";
});