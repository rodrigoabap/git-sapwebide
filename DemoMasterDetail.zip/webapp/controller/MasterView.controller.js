sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"	
], function (Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("org.unity.DemoMasterDetail.controller.MasterView", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf org.unity.DemoMasterDetail.view.MasterView
		 */
		onInit: function () {
			// access OData model declared in manifest.json file
			var oModel = this.getOwnerComponent().getModel("myModel");
			//set the model on view to be used by the UI controls
			this.getView().setModel(oModel);
		},

        onSearch: function (oEvent) {
			// create a blank filter array
			var aFilter = [];
			// get the string which was searched by the user
			var sQuery = oEvent.getParameter("query");
			// create new filter object using the searched string
			var oFilter = new sap.ui.model.Filter("ProductName", FilterOperator.Contains, sQuery);
			// push the newly created filter object in the blank filter array created above.
			aFilter.push(oFilter);
			// get the binding of items aggregation of the List
			var oBinding = this.getView().byId("productlist").getBinding("items");
			// apply filter on the obtained binding
			oBinding.filter(aFilter);
 
		},		
		onSelectionChange: function (oEvent) {
			// get the source control which triggered this event
			var oItem = oEvent.getSource();
			// get the binding context of the control
			var oCtx = oItem.getBindingContext();
			// get the binding path and truncate the first '/' so that it does not cause problem when appending the path as navigation pattern in the url
			var sPath = oCtx.getPath().substr(1);
			// get the instance of the router and navigate to Detail View. 
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("DetailView",{path:sPath});
		},
		
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf org.unity.DemoMasterDetail.view.MasterView
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf org.unity.DemoMasterDetail.view.MasterView
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf org.unity.DemoMasterDetail.view.MasterView
		 */
		//	onExit: function() {
		//
		//	}

	});

});