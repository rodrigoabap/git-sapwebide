sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("org.unity.DemoMasterDetail.controller.View1", {
		onInit: function () {
			// access OData model declared in manifest.json file
			var oModel = this.getOwnerComponent().getModel("myModel");
			//set the model on view to be used by the UI controls
			this.getView().setModel(oModel);
		},
		onObjectItemPress: function (oEvent) {
			// get the source control which triggered this event
			var oItem = oEvent.getSource();
			// get the binding context of the control
			var oCtx = oItem.getBindingContext();
			// get the binding path
			var path = oCtx.getPath();
			// use element binding to display current item
			this.getView().byId("objectheaderid").bindElement(path);
		},
		onSearch: function (oEvent) {
			// create a blank filter array
			var aFilter = [];
			// get the string which was searched by the user
			var sQuery = oEvent.getParameter("query");
			// create new filter object using the searched string
			var oFilter = new sap.ui.model.Filter("ProductName", FilterOperator.Contains, sQuery);
			// push the newly created filter object in the blank filter array created above.
			aFilter.push(oFilter);
			// get the binding of items aggregation of the List
			var oBinding = this.getView().byId("productlist").getBinding("items");
			// apply filter on the obtained binding
			oBinding.filter(aFilter);

		},
		
		onSelectionChange: function(oEvent)
		{
			var sProductID = oEvent.getSource().getBindingContext().getProperty("ProductID");
		//	var path = "Products(".concat(sProductID).concat(")");
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("detail",{ProductID:sProductID});
		},
		

	});
});