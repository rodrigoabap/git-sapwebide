sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/odata/ODataModel"
], function (JSONModel, Device, ODataModel) {
	"use strict";

	return {

		createDeviceModel: function () {
			
		//	var oModel1 = new ODataModel([sServiceUrl], [mParameters])
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}

	};
});