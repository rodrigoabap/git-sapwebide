sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Routing_SplitApp.Routing_SplitApp.controller.app", {
		onInit: function () {

		}
	});
});