sap.ui.define([
	"Routing_SplitApp/Routing_SplitApp_workflow_aprovacao/test/unit/controller/View1.controller"
], function () {
	"use strict";
});