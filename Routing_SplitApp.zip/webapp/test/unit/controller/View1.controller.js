/*global QUnit*/

sap.ui.define([
	"Routing_SplitApp/Routing_SplitApp_workflow_aprovacao/controller/View1.controller"
], function (Controller) {
	"use strict";

	QUnit.module("View1 Controller");

	QUnit.test("I should test the View1 controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});