sap.ui.define([
	"Databining_Property/Databining_Property/test/unit/controller/View1.controller"
], function () {
	"use strict";
});