sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Databining_Property.Databining_Property.controller.View1", {
	
		onInit: function () {

			var oModel = new sap.ui.model.json.JSONModel(); /** Crio a instancia do jason**/
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			/**Sabemos o json é two ewy por padrão, então acima forçamos a ser OneWay**/
			
			oModel.loadData("model/Product.json"); /**Vinculamos nosso arquivo jason atraves do medoto loadData armazenando no nosso 
			//objeto oModel que criamos (VAR)**/
			
			var oView = this; /**Crio o objeto oView do tipo this**/
			
			oView.getView().setModel(oModel,"Produtos_aggr");/**Associa o model(oModel) a nosso objeto View
			//                            Obs que define um nome(Produtos) ao model **/			
		}
	});
});