sap.ui.define([
	"HelloWorld/HelloWorld/test/unit/controller/View1.controller"
], function () {
	"use strict";
});