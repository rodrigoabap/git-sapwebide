sap.ui.define([
	"ReportSales/ReportSales/test/unit/controller/Report.controller"
], function () {
	"use strict";
});