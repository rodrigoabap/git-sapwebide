sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ovly.hanadeveloper.smarttable1.controller.View1", {
		onInit: function () {

		}
	});
});