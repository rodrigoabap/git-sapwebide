sap.ui.define([
	"ovly/hanadeveloper/smarttable1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});