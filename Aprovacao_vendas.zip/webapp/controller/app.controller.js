sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Aprovacao_vendas.Aprovacao_vendas.controller.app", {
		onInit: function () {

		}
	});
});