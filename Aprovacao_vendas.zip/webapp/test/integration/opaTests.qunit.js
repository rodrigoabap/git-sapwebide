/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Aprovacao_vendas/Aprovacao_vendas/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});