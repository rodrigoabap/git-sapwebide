sap.ui.define([
	"Aprovacao_vendas/Aprovacao_vendas/test/unit/controller/app.controller"
], function () {
	"use strict";
});